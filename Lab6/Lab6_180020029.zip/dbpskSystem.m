
function received_bits = dbpskSystem(message_bits, snrdb)
    %% -----------------------------------------Modulation--------------------------------------------

    
    %step 2 differential encoding of bits
    dbpsk_bit(1) = 1; %design parameter
    
    for i = 1:length(message_bits)
       
        dbpsk_bit(i+1) = not(xor(dbpsk_bit(i),message_bits(i))); %xnor of the consequtive bits for encoding
        
    end
    
    %disp(dbpsk_bit);
    
    %step 2 converting DBPSK bits to BPSK Symbols
    bpskSymbols = 2*dbpsk_bit - 1; 
   
    %disp(bpskSymbols);

    %% ------------------------------------------Channel---------------------------------------------

    %Signal to noise ratio 
    snrdb_now = snrdb; %signal to noise ratio in DB for this iteration
    snr_now = 10^(snrdb_now/10); %signal to noise ratio on linear scale for this iteration

    %Noise Generation
    sigma = sqrt(1/(2*snr_now)); %noise scaling parameter for each dimension
    awgn = sigma*randn(1,length(bpskSymbols)); %AWGN noise 

    %Noise Addition
    noisy_symbols = bpskSymbols + awgn; %Adding noise to the modulated symbols.
    %disp(awgn);
    %Absolute phase offset
%     phOffset = 8*pi/180; %absolute phase offset of 91 degrees
%     noisy_symbols = noisy_symbols*exp(1i*phOffset);

    %% ---------------------------------------Demodulation-------------------------------------------

    %Symbol detection by amplitude check
    recvd_symbols = []; %array to store received symbols

    for i = 1:length(noisy_symbols)

        %Symbol Detection using ML Rule ==> if amplitude > 0 symbol = 1 and -1 otherwise
        if noisy_symbols(i)>= 0
            detected_symbol = 1;
        else
            detected_symbol = -1;
        end

        %Received Symbol 
        recvd_symbols = [recvd_symbols detected_symbol];

    end
        
    %disp(recvd_symbols);
    
    %received dbpsk bits
    dbpsk_recvd = 0.5*(recvd_symbols + 1);
    
    %disp(dbpsk_recvd);
    
    %decoding the DBPSK bits
    for i = 2:length(dbpsk_recvd)
    
        received_bits(i-1) = not(xor(dbpsk_recvd(i),dbpsk_recvd(i-1)));
        
    end
    %disp(received_bits);
    
end